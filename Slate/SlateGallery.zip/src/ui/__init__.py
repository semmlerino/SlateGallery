"""UI components for SlateGallery."""
