"""Threading utilities - extracted identically from original SlateGallery.py"""

import os
import threading

from PySide6 import QtCore
from PySide6.QtCore import Signal

from .logging_config import log_function, logger

# ----------------------------- Worker Threads -----------------------------

class ScanThread(QtCore.QThread):
    scan_complete = Signal(dict, str)
    progress = Signal(int)

    def __init__(self, root_dir, cache_manager):
        super().__init__()
        self.root_dir = str(root_dir)
        self.cache_manager = cache_manager

    @log_function
    def run(self):
        try:
            # Import here to avoid circular imports
            from core.image_processor import scan_directories

            logger.info("Starting directory scan...")
            slates = scan_directories(self.root_dir)

            processed_slates = 0
            total_slates = len(slates)
            logger.debug(f"Total slates to process: {total_slates}")

            for _slate, data in slates.items():
                image_paths = data['images']
                processed_images = self.cache_manager.process_images_batch(
                    image_paths,
                    callback=lambda p: self.progress.emit(int(p))
                )
                data['images'] = processed_images

                processed_slates += 1
                if total_slates > 0:
                    progress = (processed_slates / float(total_slates)) * 100
                else:
                    progress = 100
                self.progress.emit(int(progress))
                logger.debug(f"Scan progress: {progress:.2f}%")

            # Save the scanned slates to cache
            self.cache_manager.save_cache(self.root_dir, slates)

            self.scan_complete.emit(slates, "Scan complete.")
            logger.info("Scan completed.")
        except Exception as e:
            error_message = f"Error during directory scan: {e}"
            logger.error(error_message, exc_info=True)
            self.scan_complete.emit({}, error_message)

class GenerateGalleryThread(QtCore.QThread):
    gallery_complete = Signal(bool, str)
    progress = Signal(int)

    def __init__(self, selected_slates, slates_dict, cache_manager, output_dir, root_dir, template_path, generate_thumbnails):
        super().__init__()
        self.selected_slates = selected_slates
        self.slates_dict = slates_dict
        self.cache_manager = cache_manager
        self.output_dir = output_dir
        self.root_dir = root_dir
        self.template_path = template_path
        self.generate_thumbnails = generate_thumbnails

        # Lock for thread-safe operations
        self.focal_length_lock = threading.Lock()
        self.all_focal_lengths = set()

    def run(self):
        try:
            logger.info("Generating Gallery...")
            self.progress.emit(0)

            gallery_slates = []
            total_slates = len(self.selected_slates)
            processed_slates = 0
            logger.info(f"Total slates selected: {total_slates}")

            for slate in self.selected_slates:
                images = self.slates_dict.get(slate, {}).get('images', [])
                slate_images = []

                for image in images:
                    image_data = self.process_image(image['path'])
                    if image_data is not None:
                        slate_images.append(image_data)

                if slate_images:
                    gallery_slates.append({
                        'slate': slate,
                        'images': slate_images
                    })

                processed_slates += 1
                if total_slates > 0:
                    progress = (processed_slates / float(total_slates)) * 80
                else:
                    progress = 80
                self.progress.emit(int(progress))
                logger.info(f"Metadata extraction progress: {progress:.2f}%")

            self.progress.emit(80)
            # Import here to avoid circular imports
            from core.gallery_generator import generate_html_gallery
            success = generate_html_gallery(gallery_slates, sorted(self.all_focal_lengths), self.template_path,
                                            self.output_dir, self.root_dir, self.emit_status)
            if success:
                message = "Gallery generated."
                self.progress.emit(100)
                logger.info(message)
                self.gallery_complete.emit(True, message)
            else:
                message = "Gallery generation failed."
                logger.warning(message)
                self.gallery_complete.emit(False, message)

        except Exception as e:
            error_message = f"Error during gallery generation: {e}"
            logger.error(error_message, exc_info=True)
            self.gallery_complete.emit(False, error_message)

    def process_image(self, image_path):
        try:
            # Import here to avoid circular imports
            from core.image_processor import get_exif_data, get_orientation

            exif = get_exif_data(image_path)
            focal_length = exif.get('FocalLength', None)
            focal_length_value = None

            if focal_length:
                if isinstance(focal_length, tuple):
                    try:
                        focal_length_value = float(focal_length[0]) / float(focal_length[1])
                    except Exception as e:
                        logger.warning(f"Invalid focal length tuple for {image_path}: {e}")
                else:
                    try:
                        focal_length_value = float(focal_length)
                    except Exception as e:
                        logger.warning(f"Invalid focal length value for {image_path}: {e}")

            orientation = get_orientation(image_path, exif)
            filename = os.path.basename(image_path)

            if focal_length_value:
                with self.focal_length_lock:
                    self.all_focal_lengths.add(focal_length_value)

            return {
                'original_path': image_path,
                'focal_length': focal_length_value,
                'orientation': orientation,
                'filename': filename
            }
        except Exception as e:
            logger.error(f"Error processing image {image_path}: {e}", exc_info=True)
            return None

    def emit_status(self, message):
        self.gallery_complete.emit(True, message)
